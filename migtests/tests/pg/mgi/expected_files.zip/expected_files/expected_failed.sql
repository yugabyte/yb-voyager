/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.all_allele CLUSTER ON all_allele_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.all_cellline_derivation CLUSTER ON all_cellline_derivation_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.all_label CLUSTER ON all_label_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.bib_books CLUSTER ON bib_books_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.bib_citation_cache CLUSTER ON bib_citation_cache_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.bib_notes CLUSTER ON bib_notes_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.bib_refs CLUSTER ON bib_refs_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.bib_workflow_data CLUSTER ON bib_workflow_data_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.bib_workflow_relevance CLUSTER ON bib_workflow_relevance_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.bib_workflow_status CLUSTER ON bib_workflow_status_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.bib_workflow_tag CLUSTER ON bib_workflow_tag_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.gxd_expression CLUSTER ON gxd_expression_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mgi_keyvalue CLUSTER ON mgi_keyvalue_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mgi_note CLUSTER ON mgi_note_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mgi_relationship_category CLUSTER ON mgi_relationship_category_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mgi_relationship CLUSTER ON mgi_relationship_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mgi_relationship_property CLUSTER ON mgi_relationship_property_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_assay_types CLUSTER ON mld_assay_types_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_concordance CLUSTER ON mld_concordance_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_contig CLUSTER ON mld_contig_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_contigprobe CLUSTER ON mld_contigprobe_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_expt_marker CLUSTER ON mld_expt_marker_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_expt_notes CLUSTER ON mld_expt_notes_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_expts CLUSTER ON mld_expts_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_fish CLUSTER ON mld_fish_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_fish_region CLUSTER ON mld_fish_region_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_hit CLUSTER ON mld_hit_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_hybrid CLUSTER ON mld_hybrid_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_insitu CLUSTER ON mld_insitu_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_isregion CLUSTER ON mld_isregion_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_matrix CLUSTER ON mld_matrix_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_mc2point CLUSTER ON mld_mc2point_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_mcdatalist CLUSTER ON mld_mcdatalist_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_notes CLUSTER ON mld_notes_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_ri2point CLUSTER ON mld_ri2point_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_ri CLUSTER ON mld_ri_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_ridata CLUSTER ON mld_ridata_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mld_statistics CLUSTER ON mld_statistics_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mrk_do_cache CLUSTER ON mrk_do_cache_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mrk_history CLUSTER ON mrk_history_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mrk_label CLUSTER ON mrk_label_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mrk_location_cache CLUSTER ON mrk_location_cache_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mrk_mcv_cache CLUSTER ON mrk_mcv_cache_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mrk_mcv_count_cache CLUSTER ON mrk_mcv_count_cache_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.mrk_reference CLUSTER ON mrk_reference_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.prb_alias CLUSTER ON prb_alias_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.prb_marker CLUSTER ON prb_marker_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.prb_notes CLUSTER ON prb_notes_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.prb_probe CLUSTER ON prb_probe_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.prb_ref_notes CLUSTER ON prb_ref_notes_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.prb_reference CLUSTER ON prb_reference_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.prb_rflv CLUSTER ON prb_rflv_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.prb_strain_genotype CLUSTER ON prb_strain_genotype_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.prb_strain_marker CLUSTER ON prb_strain_marker_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.prb_tissue CLUSTER ON prb_tissue_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.seq_coord_cache CLUSTER ON seq_coord_cache_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.seq_marker_cache CLUSTER ON seq_marker_cache_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.seq_probe_cache CLUSTER ON seq_probe_cache_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.seq_sequence CLUSTER ON seq_sequence_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/table.sql
*/
ALTER TABLE mgd.voc_evidence_property CLUSTER ON voc_evidence_property_pkey;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/INDEXES_table.sql
*/
ALTER TABLE mgd.all_cre_cache CLUSTER ON all_cre_cache_idx_clustered;

/*
ERROR: ALTER TABLE CLUSTER not supported yet (SQLSTATE 0A000)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/tables/INDEXES_table.sql
*/
ALTER TABLE mgd.all_knockout_cache CLUSTER ON all_knockout_cache_idx_clustered;

/*
ERROR: invalid type name "acc_accession.accid%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.acc_assignmgi(v_userkey integer, v_objectkey integer, v_mgitype text, v_prefixpart text DEFAULT 'MGI:'::text, v_nextmgi integer DEFAULT '-1'::integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_nextACC int;
v_mgiTypeKey int;
v_accID acc_accession.accid%TYPE;
v_rrID acc_accession.accid%TYPE;
v_preferred int = 1;
v_private int = 0;
BEGIN
-- NAME: ACC_assignMGI
-- DESCRIPTION:
--
-- To assign a new MGI id (MGI:xxxx) or new J (J:xxxx)
-- Add RRID for Genotypes objects (_MGIType_key = 12)
-- Increment ACC_AccessionMax.maxNumericPart
-- INPUT:
--
-- v_userKey                        : MGI_User._User_key
-- v_objectKey                      : ACC_Accession._Object_key
-- v_mgiType acc_mgitype.name%TYPE  : ACC_Accession._MGIType_key (MGI: or J:)
-- v_prefixPart acc_accession.prefixpart%TYPE : ACC_Accession.prefixPart
--		The default is 'MGI:', but 'J:' is also valid
-- v_nextMGI int DEFAULT -1 : if -1 then use next available MGI id
--		this sp does not allow an override of a generated MGI accession id
-- RETURNS:
--	VOID
--
v_nextACC := max(_Accession_key) + 1 FROM ACC_Accession;
v_mgiTypeKey := _MGIType_key FROM ACC_MGIType WHERE name = v_mgiType;
IF v_nextMGI = -1
THEN
	SELECT INTO v_nextMGI maxNumericPart + 1
	FROM ACC_AccessionMax WHERE prefixPart = v_prefixPart;
ELSIF v_prefixPart != 'J:'
THEN
    RAISE EXCEPTION E'Cannot override generation of MGI accession number';
    RETURN;
END IF;
-- check if v_nextACC already exists in ACC_Accession table
--IF (SELECT count(*) FROM ACC_Accession
--    WHERE _MGIType_key = v_mgiTypeKey
--    AND prefixPart = v_prefixPart
--    AND numericPart = v_nextACC) > 0
--THEN
--    RAISE EXCEPTION 'v_nextMGI already exists in ACC_Accession: %', v_nextMGI;
--    RETURN;
--END IF;
v_accID := v_prefixPart || v_nextMGI::char(30);
INSERT INTO ACC_Accession
(_Accession_key, accID, prefixPart, numericPart,
_LogicalDB_key, _Object_key, _MGIType_key, preferred, private,
_CreatedBy_key, _ModifiedBy_key)
VALUES(v_nextACC, v_accID, v_prefixPart, v_nextMGI, 1, v_objectKey,
v_mgiTypeKey, v_preferred, v_private, v_userKey, v_userKey);
IF (SELECT maxNumericPart FROM ACC_AccessionMax
    WHERE prefixPart = v_prefixPart) <= v_nextMGI
THEN
	UPDATE ACC_AccessionMax
	SET maxNumericPart = v_nextMGI
	WHERE prefixPart = v_prefixPart;
END IF;
-- add RRID for Genotypes
IF v_mgiTypeKey = 12
THEN
    v_nextACC := max(_Accession_key) + 1 FROM ACC_Accession;
    v_rrID := 'RRID:' || v_accID::char(30);
    INSERT INTO ACC_Accession
	(_Accession_key, accID, prefixPart, numericPart,
	_LogicalDB_key, _Object_key, _MGIType_key, preferred, private,
	_CreatedBy_key, _ModifiedBy_key)
	VALUES(v_nextACC, v_rrID, v_prefixPart, v_nextMGI, 179, v_objectKey,
	v_mgiTypeKey, v_preferred, v_private, v_userKey, v_userKey);
END IF;
RETURN;
END;
$$;

/*
ERROR: invalid type name "acc_accession.prefixPart%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.acc_insert(v_userkey integer, v_objectkey integer, v_accid text, v_logicaldb integer, v_mgitype text, v_refskey integer DEFAULT '-1'::integer, v_preferred integer DEFAULT 1, v_private integer DEFAULT 0, v_dosplit integer DEFAULT 1) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_nextACC int;
v_mgiTypeKey int;
v_prefixPart acc_accession.prefixPart%TYPE;
v_numericPart acc_accession.prefixPart%Type;
BEGIN
-- NAME: ACC_insert
-- DESCRIPTION:
--
-- To add new ACC_Accession record with out checking Accession id rules
-- If reference is given, insert record into ACC_AccessionReference
-- INPUT:
--
-- v_userKey                        : MGI_User._User_key
-- v_objectKey                      : ACC_Accession._Object_key
-- v_accID acc_accession.accid%TYPE : ACC_Accession.accID
-- v_logicalDB                      : ACC_Accession._LogicalDB_key
-- v_mgiType acc_mgitype.name%TYPE  : ACC_Accession._MGIType_key
-- v_refsKey int DEFAULT -1         : BIB_Refs._Refs_key; if Reference, then call ACCRef_insert()
-- v_preferred int DEFAULT 1        : ACC_Accession.prefixPart
-- v_private int DEFAULT 0          : ACC_Accession.private
-- v_dosplit int DEFAULT 1          : if 1, split the accession id into prefixpart/numericpart
-- RETURNS:
--
IF v_accID IS NULL
THEN
	RETURN;
END IF;
v_nextACC := max(_Accession_key) + 1 FROM ACC_Accession;
v_mgiTypeKey := _MGIType_key FROM ACC_MGIType WHERE name = v_mgiType;
v_prefixPart := v_accID;
v_numericPart := '';
-- skip the splitting...for example, the Reference/DOI ids are not split
IF v_dosplit
THEN
	-- split accession id INTO prefixPart/numericPart
	SELECT * FROM ACC_split(v_accID) INTO v_prefixPart, v_numericPart;
END IF;
IF (select count(accid) from acc_accession
        where _mgitype_key = 10 and _logicaldb_key = v_logicalDB and accid = v_accID
        group by _logicaldb_key, accid having count(*) >= 1)
THEN
        RAISE EXCEPTION E'Cannot assign same Registry:Accession Id to > 1 Strain';
        RETURN;
END IF;
IF v_numericPart = ''
THEN
	INSERT INTO ACC_Accession
	(_Accession_key, accID, prefixPart, numericPart, _LogicalDB_key, _Object_key,
 	 _MGIType_key, private, preferred, _CreatedBy_key, _ModifiedBy_key)
	VALUES(v_nextACC, v_accID, v_prefixPart, null,
               v_logicalDB, v_objectKey, v_mgiTypeKey, v_private, v_preferred, v_userKey, v_userKey);
ELSE
	INSERT INTO ACC_Accession
	(_Accession_key, accID, prefixPart, numericPart, _LogicalDB_key, _Object_key,
 	 _MGIType_key, private, preferred, _CreatedBy_key, _ModifiedBy_key)
	VALUES(v_nextACC, v_accID, v_prefixPart, v_numericPart::integer,
               v_logicalDB, v_objectKey, v_mgiTypeKey, v_private, v_preferred, v_userKey, v_userKey);
END IF;
IF v_refsKey != -1
THEN
	PERFORM ACCRef_insert(v_userKey, v_nextAcc, v_refsKey);
END IF;
RETURN;
END;
$$;

/*
ERROR: invalid type name "acc_accession.prefixPart%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.acc_update(v_userkey integer, v_acckey integer, v_accid text, v_private integer DEFAULT 0, v_origrefskey integer DEFAULT '-1'::integer, v_refskey integer DEFAULT '-1'::integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_prefixPart acc_accession.prefixPart%TYPE;
v_numericPart acc_accession.prefixPart%TYPE;
BEGIN
-- NAME: ACC_update
-- DESCRIPTION:
--
-- To update an ACC_Accession, ACC_AccessionReference records
-- INPUT:
--
-- v_userKey     : MGI_User._User_key
-- v_accKey      : ACC_Accession._Accession_key
-- v_accID       : ACC_Accession.accID
-- v_origRefsKey : original ACC_AccessionReference._Refs_key
-- v_refsKey     : new ACC_AccessionReference._Refs_key
-- v_private     : ACC_Accessioin.private
-- RETURNS:
--	VOID
--
v_numericPart := '';
IF v_accID IS NULL
THEN
	select ACC_delete_byAccKey (v_accKey);
ELSE
        -- split accession id INTO prefixPart/numericPart
        SELECT * FROM ACC_split(v_accID) INTO v_prefixPart, v_numericPart;
	IF (v_prefixPart = 'J:' or substring(v_prefixPart,1,4) = 'MGD-')
	THEN
		IF (select count(*) from ACC_Accession
		    where numericPart = v_numericPart::integer
			  and prefixPart = v_prefixPart) >= 1
		THEN
                        RAISE EXCEPTION E'Duplicate MGI Accession Number';
                        RETURN;
		END IF;
	END IF;
	IF v_numericPart = ''
	THEN
		update ACC_Accession
	       	set accID = v_accID,
		   	prefixPart = v_prefixPart,
		   	numericPart = null,
                        private = v_private,
		   	_ModifiedBy_key = v_userKey,
		   	modification_date = now()
	       	where _Accession_key = v_accKey;
        ELSE
		update ACC_Accession
	       	set accID = v_accID,
		   	prefixPart = v_prefixPart,
		   	numericPart = v_numericPart::integer,
                        private = v_private,
		   	_ModifiedBy_key = v_userKey,
		   	modification_date = now()
	       	where _Accession_key = v_accKey;
	END IF;
	IF v_refsKey > 0
	THEN
		update ACC_AccessionReference
		       set _Refs_key = v_refsKey,
		           _ModifiedBy_key = v_userKey,
		           modification_date = now()
		           where _Accession_key = v_accKey and _Refs_key = v_origRefsKey;
	END IF;
END IF;
END;
$$;

/*
ERROR: invalid type name "all_allele.symbol%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.all_createwildtype(v_userkey integer, v_markerkey integer, v_symbol text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_asymbol all_allele.symbol%TYPE;
BEGIN
-- NAME: ALL_createWildType
-- DESCRIPTION:
--
-- Create a Wild Type Allele
-- Use Reference = J:23000
-- Set all other attributes = Not Applicable
-- INPUT:
-- v_userKey   : MGI_User._User_key
-- v_markerKey : MRK_Marker._Marker_key
-- v_symbol mrk_marker.symbol%TYPE
-- RETURNS:
--	VOID
--
v_asymbol := v_symbol || '<+>';
PERFORM ALL_insertAllele (
	v_userKey,
	v_markerKey,
	v_asymbol,
	'wild type',
	null,
	1,
	v_userKey,
	v_userKey,
	v_userKey,
	current_date,
	-2,
	'Not Applicable',
	'Not Applicable',
        'Approved',
        null,
        'Not Applicable',
        'Not Specified',
        'Not Specified',
        'Curated'
	);
IF NOT FOUND
THEN
	RAISE EXCEPTION E'ALL_createWildType: PERFORM ALL_insertAllele failed';
END IF;
END;
$$;

/*
ERROR: invalid type name "all_allele.isextinct%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.all_insertallele(v_userkey integer, v_markerkey integer, v_symbol text, v_name text, v_refskey integer DEFAULT NULL::integer, v_iswildtype integer DEFAULT 0, v_createdby integer DEFAULT 1001, v_modifiedby integer DEFAULT 1001, v_approvedby integer DEFAULT NULL::integer, v_approval_date timestamp without time zone DEFAULT NULL::timestamp without time zone, v_strainkey integer DEFAULT '-1'::integer, v_amode text DEFAULT 'Not Specified'::text, v_atype text DEFAULT 'Not Specified'::text, v_astatus text DEFAULT 'Approved'::text, v_oldsymbol text DEFAULT NULL::text, v_transmission text DEFAULT 'Not Applicable'::text, v_collection text DEFAULT 'Not Specified'::text, v_qualifier text DEFAULT 'Not Specified'::text, v_mrkstatus text DEFAULT 'Curated'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_alleleKey int;
v_createdByKey int;
v_modifiedByKey int;
v_approvedByKey int;
v_modeKey int;
v_typeKey int;
v_statusKey int;
v_transmissionKey int;
v_collectionKey int;
v_assocKey int;
v_qualifierKey int;
v_mrkstatusKey int;
v_isExtinct all_allele.isextinct%TYPE;
v_isMixed all_allele.ismixed%TYPE;
BEGIN
-- NAME: ALL_insertAllele
-- DESCRIPTION:
--
-- To insert a new Allele into ALL_Allele
-- Also calls: MGI_insertReferenceAssoc() to create 'Original'/1011 reference
-- INPUT:
--
-- see below
-- RETURNS:
--	VOID
--
v_alleleKey := nextval('all_allele_seq');
IF v_createdBy IS NULL
THEN
	v_createdByKey := v_userKey;
ELSE
	v_createdByKey := _User_key from MGI_User where login = current_user;
END IF;
IF v_modifiedBy IS NULL
THEN
	v_modifiedByKey := v_userKey;
ELSE
	v_modifiedByKey := _User_key from MGI_User where login = current_user;
END IF;
IF v_approvedBy IS NULL
THEN
	v_approvedByKey := v_userKey;
ELSE
	v_approvedByKey := _User_key from MGI_User where login = current_user;
END IF;
v_modeKey := _Term_key from VOC_Term where _Vocab_key = 35 AND term = v_amode;
v_typeKey := _Term_key from VOC_Term where _Vocab_key = 38 AND term = v_atype;
v_statusKey := _Term_key from VOC_Term where _Vocab_key = 37 AND term = v_astatus;
v_transmissionKey := _Term_key from VOC_Term where _Vocab_key = 61 AND term = v_transmission;
v_collectionKey := _Term_key from VOC_Term where _Vocab_key = 92 AND term = v_collection;
v_qualifierKey := _Term_key from VOC_Term where _Vocab_key = 70 AND term = v_qualifier;
v_mrkstatusKey := _Term_key from VOC_Term where _Vocab_key = 73 AND term = v_mrkstatus;
v_isExtinct := 0;
v_isMixed := 0;
IF v_astatus = 'Approved' AND v_approval_date IS NULL
THEN
	v_approval_date := now();
END IF;
/* Insert New Allele into ALL_Allele */
INSERT INTO ALL_Allele
(_Allele_key, _Marker_key, _Strain_key, _Mode_key, _Allele_Type_key, _Allele_Status_key, _Transmission_key,
        _Collection_key, symbol, name, isWildType, isExtinct, isMixed,
	_Refs_key, _MarkerAllele_Status_key,
        _CreatedBy_key, _ModifiedBy_key, _ApprovedBy_key, approval_date, creation_date, modification_date)
VALUES(v_alleleKey, v_markerKey, v_strainKey, v_modeKey, v_typeKey, v_statusKey, v_transmissionKey,
        v_collectionKey, v_symbol, v_name, v_isWildType, v_isExtinct, v_isMixed,
	v_refsKey, v_mrkstatusKey,
        v_createdByKey, v_modifiedByKey, v_approvedByKey, v_approval_date, now(), now())
;
IF v_refsKey IS NOT NULL
THEN
        PERFORM MGI_insertReferenceAssoc (v_userKey, 11, v_alleleKey, v_refsKey, 1011);
END IF;
--IF (v_oldSymbol IS NOT NULL) AND (v_markerKey IS NOT NULL)
--THEN
        --UPDATE MLD_Expt_Marker SET _Allele_key = v_alleleKey
	--WHERE _Marker_key = v_markerKey AND gene = v_oldSymbol;
--END IF;
END;
$$;

/*
ERROR: invalid type name "all_label.label%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.all_reloadlabel(v_allelekey integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_userKey int;
v_labelstatusKey int;
v_priority int;
v_label all_label.label%TYPE;
v_labelType all_label.labelType%TYPE;
v_labelTypeName all_label.labelTypeName%TYPE;
BEGIN
-- NAME: ALL_reloadLabel
-- DESCRIPTION:
--
-- reload ALL_Label for given Allele
-- INPUT:
--
-- v_alleleKey : ALL_Allele._Allele_key
-- RETURNS:
--	VOID
--
-- Delete all ALL_Label records for a Allele and regenerate
DELETE FROM ALL_Label WHERE _Allele_key = v_alleleKey;
FOR v_labelstatusKey, v_priority, v_label, v_labelType, v_labelTypeName IN
SELECT DISTINCT 1 as _Label_Status_key, 1 as priority,
a.symbol, 'AS' as labelType, 'allele symbol' as labelTypeName
FROM ALL_Allele a
WHERE a._Allele_key = v_alleleKey
AND a.isWildType = 0
UNION
SELECT distinct 1 as _Label_Status_key, 2 as priority,
a.name, 'AN' as labelType, 'allele name' as labelTypeName
FROM ALL_Allele a
WHERE a._Allele_key = v_alleleKey
AND a.isWildType = 0
UNION
SELECT 1 as _Label_Status_key, 3 as priority,
s.synonym, 'AY' as labelType, 'synonym' as labelTypeName
FROM MGI_Synonym_Allele_View s
WHERE s._Object_key = v_alleleKey
LOOP
	INSERT INTO ALL_Label
	(_Allele_key, _Label_Status_key, priority, label, labelType, labelTypeName, creation_date, modification_date)
	VALUES (v_alleleKey, v_labelstatusKey, v_priority, v_label, v_labelType, v_labelTypeName, now(), now())
	;
END LOOP;
END;
$$;

/*
ERROR: invalid type name "acc_accession.accID%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.img_setpdo(v_pixid integer, v_xdim integer, v_ydim integer, v_image_key integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_accID acc_accession.accID%TYPE;
v_prefix varchar(4);
v_imageLDB int;
v_imageType int;
BEGIN
-- NAME: IMG_setPDO
-- DESCRIPTION:
--
-- adds the PIX id to the MGI Image (ACC_Accession, IMG_Image)
-- set the IMG_Image.xDim, yDim values
-- If image_key is valid and a PIX foreign accession number
-- does not already exist for the _Image_key and the PIX: accession
-- ID does not already exist, the new ID is added to ACC_Accession
-- and the x,y dim update the image record.
-- ASSUMES:
-- - _LogicalDB_key for "MGI Image Archive" is 19,
-- - _MGIType_key for mgi Image objects is 9
-- REQUIRES:
-- - four integer inputs
-- - _Image_key exists
-- - _Image_key is not referenced by an existing PIX:#
-- - PIX:# does not exist (referencing another _Image_key)
-- INPUT:
-- v_pixID     : ACC_Accession.accID
-- v_xDim      : IMG_Image.xDmin
-- v_yDim      : IMG_Image.yDmin
-- v_image_key : IMG_Image._Image_key
-- RETURNS:
--	VOID
v_prefix := 'PIX:';
v_imageLDB := 19;
v_imageType := 9;
IF v_pixID IS NULL OR v_image_key IS NULL OR v_xDim IS NULL OR v_yDim IS NULL
THEN
	RAISE EXCEPTION E'IMG_setPDO: All four arguments must be non-NULL.';
	RETURN;
ELSE
	v_accID := v_prefix || v_pixID;
END IF;
-- ck for missing image rec
IF NOT EXISTS (SELECT 1 FROM IMG_Image WHERE _Image_key = v_image_key)
THEN
	RAISE EXCEPTION E'IMG_setPDO: % _Image_key does not exist.', v_image_key;
	RETURN;
END IF;
-- check that this PIX:# does not already exist
IF EXISTS (SELECT 1 FROM ACC_Accession
   WHERE accID = v_accID AND _MGIType_key = v_imageType
   AND _LogicalDB_key = v_imageLDB
   )
THEN
	RAISE EXCEPTION E'IMG_setPDO: % accession already exists.', v_accID;
	RETURN;
END IF;
-- check that image record is not referenced by another PIX:#
IF EXISTS (SELECT 1 FROM ACC_Accession
   WHERE _Object_key = v_image_key AND prefixPart = v_prefix
   AND _LogicalDB_key = v_imageLDB AND _MGIType_key = v_imageType
   )
THEN
	RAISE EXCEPTION E'IMG_setPDO: A PIX: accession already exists for _Image_key %.', v_image_key;
	RETURN;
END IF;
-- insert the new PIX: accession record
PERFORM ACC_insert (1001, v_image_key, v_accID, v_imageLDB, 'Image', -1, 1, 1);
IF NOT FOUND
THEN
	RAISE EXCEPTION E'IMG_setPDO: ACC_insert failed.';
	RETURN;
END IF;
-- set the image dimensions
UPDATE IMG_Image
SET xDim = v_xDim, yDim = v_yDim
WHERE _Image_key = v_image_key
;
IF NOT FOUND
THEN
        RAISE EXCEPTION E'IMG_setPDO: Update x,y Dimensions failed.';
        RETURN;
END IF;
END;
$$;

/*
ERROR: invalid type name "prb_source.age%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.mgi_resetageminmax(v_table text, v_key integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_pkey int; 	/* primary key of records to UPDATE */
v_age prb_source.age%TYPE;
v_ageMin numeric;
v_ageMax numeric;
age_cursor refcursor;
BEGIN
-- Update the Age Min, Age Max values
IF (v_table = 'GXD_Expression')
THEN
	OPEN age_cursor FOR
	SELECT _Expression_key, age
	FROM GXD_Expression
	WHERE _Expression_key = v_key;
ELSIF (v_table = 'GXD_GelLane')
THEN
	OPEN age_cursor FOR
	SELECT _GelLane_key, age
	FROM GXD_GelLane
	WHERE _GelLane_key = v_key;
ELSIF (v_table = 'GXD_Specimen')
THEN
	OPEN age_cursor FOR
	SELECT _Specimen_key, age
	FROM GXD_Specimen
	WHERE _Specimen_key = v_key;
ELSIF (v_table = 'PRB_Source')
THEN
	OPEN age_cursor FOR
	SELECT _Source_key, age
	FROM PRB_Source
	WHERE _Source_key = v_key;
ELSIF (v_table = 'GXD_HTSample')
THEN
	OPEN age_cursor FOR
	SELECT _Sample_key, age
	FROM GXD_HTSample
	WHERE _Sample_key = v_key;
ELSE
	RETURN;
END IF;
LOOP
	FETCH age_cursor INTO v_pkey, v_age;
	EXIT WHEN NOT FOUND;
	-- see PRB_ageMinMex for exceptions
	SELECT * FROM PRB_ageMinMax(v_age) into v_ageMin, v_ageMax;
        -- no ageMin/ageMax null values
        -- commented out; there are dependcies upstream that are expecting null
        IF (v_ageMin is null)
        THEN
                v_ageMin := -1;
                v_ageMax := -1;
        END IF;
	IF (v_table = 'GXD_Expression')
	THEN
		UPDATE GXD_Expression
		SET ageMin = v_ageMin, ageMax = v_ageMax WHERE _Expression_key = v_pkey;
	ELSIF (v_table = 'GXD_GelLane')
	THEN
		UPDATE GXD_GelLane
		SET ageMin = v_ageMin, ageMax = v_ageMax WHERE _GelLane_key = v_pkey;
	ELSIF (v_table = 'GXD_Specimen')
	THEN
		UPDATE GXD_Specimen
		SET ageMin = v_ageMin, ageMax = v_ageMax WHERE _Specimen_key = v_pkey;
	ELSIF (v_table = 'PRB_Source')
	THEN
		UPDATE PRB_Source
		SET ageMin = v_ageMin, ageMax = v_ageMax WHERE _Source_key = v_pkey;
	ELSIF (v_table = 'GXD_HTSample')
	THEN
		UPDATE GXD_HTSample
		SET ageMin = v_ageMin, ageMax = v_ageMax WHERE _Sample_key = v_pkey;
	END IF;
END LOOP;
CLOSE age_cursor;
RETURN;
END;
$$;

/*
ERROR: invalid type name "mrk_marker.symbol%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.mrk_allelewithdrawal(v_userkey integer, v_oldkey integer, v_newkey integer, v_refskey integer, v_eventreasonkey integer, v_addassynonym integer DEFAULT 1) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_oldSymbol mrk_marker.symbol%TYPE;
v_oldName mrk_marker.name%TYPE;
v_newSymbol  mrk_marker.symbol%TYPE;
BEGIN
-- This procedure will process an allele marker withdrawal.
-- An allele marker withdrawal requires:
--	a) the "old" marker key
--	b) the "new" marker key
--	c) the reference key
--	d) the event reason key
v_oldSymbol := symbol
FROM MRK_Marker
WHERE _Marker_key = v_oldKey
     AND _Organism_key = 1
     AND _Marker_Status_key = 1
;
v_oldName := name
FROM MRK_Marker
WHERE _Marker_key = v_oldKey
     AND _Organism_key = 1
     AND _Marker_Status_key = 1
;
v_newSymbol := symbol
FROM MRK_Marker
WHERE _Marker_key = v_newKey
     AND _Organism_key = 1
     AND _Marker_Status_key = 1
;
IF v_oldSymbol IS NULL
THEN
        RAISE EXCEPTION E'\nMRK_alleleWithdrawal : Invalid Old Symbol Key %', v_oldKey;
        RETURN;
END IF;
IF v_newSymbol IS NULL
THEN
        RAISE EXCEPTION E'\nMRK_alleleWithdrawal : Invalid New Symbol Key %', v_newKey;
        RETURN;
END IF;
PERFORM MRK_mergeWithdrawal (v_userKey, v_oldKey, v_newKey, v_refsKey, 106563607, v_eventReasonKey, v_addAsSynonym);
IF NOT FOUND
THEN
        RAISE EXCEPTION E'\nMRK_alleleWithdrawal : Could not execute allele withdrawal';
        RETURN;
END IF;
RETURN;
END;
$$;

/*
ERROR: invalid type name "mrk_history.name%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.mrk_copyhistory(v_userkey integer, v_oldkey integer, v_newkey integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_historyKey int;
v_refsKey int;
v_eventKey int;
v_eventReasonKey int;
v_createdByKey int;
v_modifiedByKey int;
v_name mrk_history.name%TYPE;
v_event_date mrk_history.event_date%TYPE;
BEGIN
-- Copy History of v_oldKey to v_newKey
FOR v_historyKey, v_refsKey, v_eventKey, v_eventReasonKey, v_name, v_event_date IN
SELECT _History_key, _Refs_key, _Marker_Event_key, _Marker_EventReason_key, name, event_date
FROM MRK_History
WHERE _Marker_key = v_oldKey
ORDER BY sequenceNum
LOOP
	PERFORM MRK_insertHistory (v_userKey, v_newKey, v_historyKey, v_refsKey, v_eventKey,
		v_eventReasonKey, v_name, v_event_date);
END LOOP;
END;
$$;

/*
ERROR: invalid type name "mrk_marker.name%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.mrk_deletewithdrawal(v_userkey integer, v_oldkey integer, v_refskey integer, v_eventreasonkey integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_oldName mrk_marker.name%TYPE;
BEGIN
-- This procedure will process a delete withdrawal.
-- A delete marker withdrawal requires:
--	a) the "old" marker key
--	b) a reference key
IF EXISTS (SELECT 1 FROM ALL_Allele WHERE _Marker_key = v_oldKey and isWildType = 0)
THEN
        RAISE EXCEPTION E'\nMRK_deleteWithdrawal: Cannot Delete:  Marker is referenced by Allele.';
        RETURN;
END IF;
v_oldName := (SELECT name FROM MRK_Marker
	 WHERE _Organism_key = 1
	 AND _Marker_Status_key = 1
	 AND _Marker_key = v_oldKey);
-- Update Marker info
UPDATE MRK_Marker
SET name = 'withdrawn', _Marker_Status_key = 2 ,
	cmOffset = -999.0,
	_ModifiedBy_key = v_userKey, modification_date = now()
WHERE _Marker_key = v_oldKey
;
IF NOT FOUND
THEN
	RAISE EXCEPTION E'MRK_deleteWithdrawal: Could not update marker';
	RETURN;
END IF;
-- Add History line for withdrawal
PERFORM MRK_insertHistory (v_userKey, v_oldKey, v_oldKey, v_refsKey, 106563609, v_eventReasonKey, v_oldName);
IF NOT FOUND
THEN
	RAISE EXCEPTION E'MRK_deleteWithdrawal: Could not add history';
	RETURN;
END IF;
-- Remove old symbol's wild type allele
DELETE FROM ALL_Allele a
USING MRK_Marker m
WHERE m._Marker_key = v_oldKey
AND m._Marker_key = a._Marker_key
AND a.isWildType = 1
;
-- Remove MGI_Relationships that are annotated to this Marker
CREATE TEMP TABLE toDelete ON COMMIT DROP
AS SELECT r._Relationship_key
FROM MGI_Relationship r, MGI_Relationship_Category c
WHERE r._Object_key_1 = v_oldKey
AND r._Category_key  = c._Category_key
AND c._MGIType_key_1 = 2
UNION
SELECT r._Relationship_key
FROM MGI_Relationship r, MGI_Relationship_Category c
WHERE r._Object_key_2 = v_oldKey
AND r._Category_key  = c._Category_key
AND c._MGIType_key_2 = 2
;
DELETE
FROM MGI_Relationship
USING toDelete d
WHERE d._Relationship_key = MGI_Relationship._Relationship_key
;
RETURN;
END;
$$;

/*
ERROR: invalid type name "mrk_marker.symbol%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.mrk_mergewithdrawal(v_userkey integer, v_oldkey integer, v_newkey integer, v_refskey integer, v_eventkey integer, v_eventreasonkey integer, v_addassynonym integer DEFAULT 1) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_alleleOf int;
v_assigningRefKey int;
v_synTypeKey int;
v_oldSymbol mrk_marker.symbol%TYPE;
v_oldName mrk_marker.name%TYPE;
v_newSymbol mrk_marker.symbol%TYPE;
v_newChr mrk_marker.chromosome%TYPE;
v_withdrawnName mrk_marker.name%TYPE;
v_cytogeneticOffset mrk_marker.cytogeneticOffset%TYPE;
v_cmOffset mrk_marker.cmOffset%TYPE;
v_alleleSymbol all_allele.symbol%TYPE;
BEGIN
-- This procedure will process a merge marker withdrawal.
-- A merge withdrawal is a withdrawal where both the "old" and "new"
-- markers already exist in the database.
-- A merge marker withdrawal requires:
--	a) the "old" marker key
--	b) the "new" marker key
--	c) the reference key
--	d) the event key
--	e) the event reason key
--	f) the "add as synonym" flag
IF v_oldKey = v_newKey
THEN
	RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Cannot Merge a Symbol into itself: %, %', v_oldKey, v_newKey;
	RETURN;
END IF;
v_oldSymbol := symbol
	FROM MRK_Marker
	WHERE _Marker_key = v_oldKey
     	AND _Organism_key = 1
     	AND _Marker_Status_key = 1;
v_oldName := name
	FROM MRK_Marker
	WHERE _Marker_key = v_oldKey
     	AND _Organism_key = 1
     	AND _Marker_Status_key = 1;
IF v_oldSymbol IS NULL
THEN
	RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Invalid Old Symbol Key %', v_oldKey;
	RETURN;
END IF;
v_newSymbol := (
	SELECT symbol
	FROM MRK_Marker
	WHERE _Marker_key = v_newKey
     	AND _Organism_key = 1
     	AND _Marker_Status_key = 1
	);
IF v_newSymbol IS NULL
THEN
	RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Invalid New Symbol Key %', v_newKey;
	RETURN;
END IF;
-- Prevent the merge if the a Marker Detail Clip exists for both symbols
IF EXISTS (SELECT 1 FROM MRK_Notes WHERE _Marker_key = v_oldKey) AND
   EXISTS (SELECT 1 FROM MRK_Notes WHERE _Marker_key = v_newKey)
THEN
        RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Cannot Merge:  both Symbols contain a Marker Detail Clip.';
        RETURN;
END IF;
-- Else, continue....
if v_eventKey = 4
THEN
	v_withdrawnName := 'withdrawn, allele of ' || v_newSymbol;
	v_alleleOf := 1;
ELSE
	v_withdrawnName := 'withdrawn, = ' || v_newSymbol;
	v_alleleOf := 0;
END IF;
--see TR11855 : make sure new term exists before turning this on
--if v_eventKey = 4
--THEN
        -- Update needsReview flag for strains
        --PERFORM PRB_setStrainReview (v_oldKey, NULL, (select _Term_key from VOC_Term where _Vocab_key = 56 and term = 'Needs Review - Chr'));
        --IF NOT FOUND
        --THEN
	        --RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not flag Strain record for needing review';
	        --RETURN;
        --END IF;
--END IF;
-- If new symbol has a chromosome of UN, update the new symbol's chromosome value
-- with the old symbol chromosome value
IF (SELECT chromosome FROM MRK_Marker WHERE _Marker_key = v_newKey) = 'UN'
THEN
	v_newChr := (SELECT chromosome FROM MRK_Marker WHERE _Marker_key = v_oldKey);
	UPDATE MRK_Marker
	SET chromosome = v_newChr, _ModifiedBy_key = v_userKey, modification_date = now()
	WHERE _Marker_key = v_newKey
	;
	IF NOT FOUND
	THEN
		RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not update new symbol/chromosome';
		RETURN;
	END IF;
END IF;
-- Update cytogenetic/offset values of new symbol
v_cytogeneticOffset := (SELECT cytogeneticOffset FROM MRK_Marker WHERE _Marker_key = v_oldKey);
v_cmOffset := (SELECT cmOffset FROM MRK_Marker WHERE _Marker_key = v_oldKey);
UPDATE MRK_Marker
SET cytogeneticOffset = v_cytogeneticOffset, cmOffset = v_cmOffset
WHERE _Marker_key = v_newKey
;
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not update cytogenetic/offset values';
	RETURN;
END IF;
-- Update name/cytogenetic/offset of old symbol
UPDATE MRK_Marker
SET name = v_withdrawnName, cytogeneticOffset = null, _Marker_Status_key = 2, cmOffset = -999.0,
	_ModifiedBy_key = v_userKey, modification_date = now()
WHERE _Marker_key = v_oldKey
;
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not update name of old symbol : %', v_oldKey;
	RETURN;
END IF;
-- Merge potential duplicate wild type alleles of old and new symbols
-- before converting oldsymbol alleles
PERFORM ALL_mergeWildTypes (v_oldKey, v_newKey, v_oldSymbol, v_newSymbol);
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not merge wild type alleles';
	RETURN;
END IF;
-- Convert Remaining Alleles
PERFORM ALL_convertAllele (v_userKey, v_oldKey, v_oldSymbol, v_newSymbol, v_alleleOf);
--IF NOT FOUND
--THEN
--	RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not convert alleles';
--	RETURN;
--END IF;
IF v_alleleOf = 1
THEN
	-- If no alleles exist for the old symbol, create a newSymbol<oldSymbol> allele
	IF NOT EXISTS (SELECT 1 FROM ALL_Allele WHERE _Marker_key = v_oldKey)
	THEN
		v_alleleSymbol := v_newSymbol || '<' || v_oldSymbol || '>';
		PERFORM ALL_insertAllele (v_userKey, v_newKey, v_alleleSymbol, v_oldName,
			v_refsKey, 0, null, null, null, null,
			-1, 'Not Specified', 'Not Specified', 'Approved', v_oldSymbol);
		IF NOT FOUND
		THEN
			RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not insert allele';
			RETURN;
		END IF;
	END IF;
END IF;
-- Merge Marker Feature Relationships (MGI_Relationship)
PERFORM MGI_mergeRelationship (v_oldKey, v_newKey);
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not merge Marker Feature Relationships';
	RETURN;
END IF;
-- Update current symbols
UPDATE MRK_Current
SET _Current_key = v_newKey
WHERE _Marker_key = v_oldKey
;
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not update current symbols';
	RETURN;
END IF;
-- Copy History records from old symbol to new symbol
PERFORM MRK_copyHistory (v_userKey, v_oldKey, v_newKey);
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not copy history records';
	RETURN;
END IF;
-- Insert history record for withdrawal
PERFORM MRK_insertHistory (v_userKey, v_newKey, v_oldKey, v_refsKey, v_eventKey, v_eventReasonKey, v_oldName);
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not create history record';
	RETURN;
END IF;
-- Remove history records from old symbol
DELETE FROM MRK_History WHERE _Marker_key = v_oldKey;
-- Insert withdrawn symbol into Synonym table
-- Use assigning reference
IF v_addAsSynonym = 1
THEN
	v_assigningRefKey := (
		SELECT DISTINCT _Refs_key
		FROM MRK_History_View
		WHERE _Marker_key = v_newKey
		AND history = v_oldSymbol
		AND _Marker_Event_key = 1
		ORDER BY _Refs_key
		LIMIT 1
		);
	-- If oldSymbol is a Riken symbol (ends with 'Rik'),
	-- then synonym type = 'similar' else synonym type = 'exact'
	IF EXISTS (SELECT 1
		   FROM MRK_Marker
                   WHERE _Marker_key = v_oldKey
                        AND _Organism_key = 1
                        AND _Marker_Status_key = 1
		        AND symbol like '%Rik'
		   )
	THEN
	    v_synTypeKey := 1005;
        ELSE
	    v_synTypeKey := 1004;
        END IF;
	PERFORM MGI_insertSynonym (v_userKey, v_newKey, 2, v_synTypeKey, v_oldSymbol, v_assigningRefKey, 1);
	IF NOT FOUND
	THEN
		RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not add synonym';
		RETURN;
	END IF;
END IF;
-- Remove old symbol's wild type allele
DELETE FROM ALL_Allele a
USING MRK_Marker m
WHERE m._Marker_key = v_oldKey
AND m._Marker_key = a._Marker_key
AND a.isWildType = 1
;
-- Update keys from old key to new key
PERFORM MRK_updateKeys (v_oldKey, v_newKey);
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_mergeWithdrawal: Could not update keys';
	RETURN;
END IF;
END;
$$;

/*
ERROR: invalid type name "mrk_marker.chromosome%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.mrk_reloadlocation(v_markerkey integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_markerTypeKey int;
v_organismKey int;
v_sequenceNum int;
v_chromosome mrk_marker.chromosome%TYPE;
v_cytogeneticOffset mrk_marker.cytogeneticOffset%TYPE;
v_cmoffset mrk_marker.cmoffset%TYPE;
v_startCoordinate seq_coord_cache.startCoordinate%TYPE;
v_endCoordinate seq_coord_cache.endCoordinate%TYPE;
v_strand seq_coord_cache.strand%TYPE;
v_mapUnits voc_term.term%TYPE;
v_provider map_coord_collection.abbreviation%TYPE;
v_version seq_coord_cache.version%TYPE;
v_genomicChromosome seq_coord_cache.chromosome%TYPE;
BEGIN
DELETE FROM MRK_Location_Cache where _Marker_key = v_markerKey;
FOR v_chromosome, v_cytogeneticOffset, v_markerTypeKey, v_organismKey, v_cmoffset,
    v_sequenceNum, v_startCoordinate, v_endCoordinate, v_strand, v_mapUnits,
    v_provider, v_version, v_genomicChromosome
IN
select m.chromosome, m.cytogeneticOffset, m._Marker_Type_key, m._Organism_key, m.cmOffset,
c.sequenceNum,
f.startCoordinate, f.endCoordinate, f.strand, u.term, cl.abbreviation, cc.version, gc.chromosome as genomicChromosome
from MRK_Marker m, MRK_Chromosome c,
MAP_Coord_Collection cl, MAP_Coordinate cc, MAP_Coord_Feature f, VOC_Term u, MRK_Chromosome gc
where m._Marker_key = v_markerKey
and m._Organism_key = c._Organism_key
and m.chromosome = c.chromosome
and m._Marker_key = f._Object_key
and f._MGIType_key = 2
and f._Map_key = cc._Map_key
and cc._Collection_key = cl._Collection_key
and cc._Units_key = u._Term_key
and cc._Object_key = gc._Chromosome_key
UNION
select m.chromosome, m.cytogeneticOffset, m._Marker_Type_key, m._Organism_key, m.cmOffset,
ch.sequenceNum,
c.startCoordinate, c.endCoordinate, c.strand, c.mapUnits, cl.abbreviation, c.version, c.chromosome as genomicChromosome
from MRK_Marker m, MRK_Chromosome ch,
     SEQ_Marker_Cache mc, SEQ_Coord_Cache c, MAP_Coordinate cc,
     MAP_Coord_Collection cl
where m._Marker_key = v_markerKey
and m._Organism_key = ch._Organism_key
and m.chromosome = ch.chromosome
and m._Marker_key = mc._Marker_key
and mc._Qualifier_key = 615419
and mc._Sequence_key = c._Sequence_key
and c._Map_key = cc._Map_key
and cc._Collection_key = cl._Collection_key
UNION
select m.chromosome, m.cytogeneticOffset, m._Marker_Type_key, m._Organism_key, m.cmOffset,
c.sequenceNum,NULL,NULL,NULL,NULL,NULL,NULL,NULL
from MRK_Marker m, MRK_Chromosome c
where m._Marker_key = v_markerKey
and m._Organism_key = c._Organism_key
and m.chromosome = c.chromosome
and not exists (select 1 from SEQ_Marker_Cache mc, SEQ_Coord_Cache c
where m._Marker_key = mc._Marker_key
and mc._Qualifier_key = 615419
and mc._Sequence_key = c._Sequence_key)
and not exists (select 1 from MAP_Coord_Feature f
where m._Marker_key = f._Object_key
and f._MGIType_key = 2)
UNION
select m.chromosome, m.cytogeneticOffset, m._Marker_Type_key, m._Organism_key, m.cmOffset,
c.sequenceNum,NULL,NULL,NULL,NULL,NULL,NULL,NULL
from MRK_Marker m, MRK_Chromosome c
where m._Marker_key = v_markerKey
and m._Organism_key = c._Organism_key
and m.chromosome = c.chromosome
and not exists (select 1 from SEQ_Marker_Cache mc, SEQ_Coord_Cache c
where m._Marker_key = mc._Marker_key
and mc._Qualifier_key = 615419
and mc._Sequence_key = c._Sequence_key)
and not exists (select 1 from MAP_Coord_Feature f
where m._Marker_key = f._Object_key
and f._MGIType_key = 2)
LOOP
	INSERT INTO MRK_Location_Cache
	(_Marker_key, _Marker_Type_key, _Organism_key, chromosome, sequenceNum, cytogeneticOffset,
		cmoffset, genomicChromosome, startCoordinate, endCoordinate, strand, mapUnits, provider, version)
	VALUES(v_markerKey, v_markerTypeKey, v_organismKey, v_chromosome, v_sequenceNum, v_cytogeneticOffset,
		v_cmoffset, v_genomicChromosome, v_startCoordinate, v_endCoordinate, v_strand, v_mapUnits, v_provider, v_version)
	;
        -- only process 1st value
        EXIT;
END LOOP;
END;
$$;

/*
ERROR: invalid type name "mrk_marker.name%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.mrk_simplewithdrawal(v_userkey integer, v_oldkey integer, v_refskey integer, v_eventreasonkey integer, v_newsymbol text, v_newname text, v_addassynonym integer DEFAULT 1) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_newKey int;
v_withdrawnName mrk_marker.name%TYPE;
v_savesymbol mrk_marker.symbol%TYPE;
BEGIN
-- This procedure will process a simple marker withdrawal.
-- A simple marker withdrawal requires:
--	a) the "old" marker key
--	b) the reference key
--	c) the event reason key
--	c) the "new" marker symbol which does not already exist
--	d) the "new" marker name
--	e) the "add as synonym" flag
--
--  Since the server is not case-sensitive, the caller is
--  responsible for making sure the new symbol is unique and correct.
--
v_withdrawnName := 'withdrawn, = ' || v_newSymbol;
v_newKey := nextval('mrk_marker_seq') as mrk_marker_seq;
CREATE TEMP TABLE mrk_tmp ON COMMIT DROP
AS SELECT distinct m.symbol as oldSymbol, m.name as oldName, h._Refs_key as assigningRefKey
FROM MRK_Marker m, MRK_History h
WHERE m._Organism_key = 1
     AND m._Marker_Status_key = 1
     AND m._Marker_key = v_oldKey
     AND m._Marker_key = h._Marker_key
     AND h._History_key = v_oldKey
     AND h._Marker_Event_key = 106563604
;
IF (SELECT count(*) FROM mrk_tmp) = 0
THEN
	RAISE EXCEPTION E'\nMRK_simpleWithdrawal: Marker History is missing "assigned" event (%)', v_newSymbol;
	RETURN;
END IF;
-- Check for duplicates; exclude cytogenetic markers
IF EXISTS (SELECT * FROM MRK_Marker
	WHERE _Organism_key = 1
	AND _Marker_Status_key = 1
	AND _Marker_Type_key != 3
	AND symbol = v_newSymbol)
THEN
	RAISE EXCEPTION E'\nMRK_simpleWithdrawal: Duplicate Symbol (%)', v_newSymbol;
	RETURN;
END IF;
v_savesymbol := symbol FROM MRK_Marker WHERE _Marker_key = v_oldKey;
-- Create a new marker record using the old marker record as the template
INSERT INTO MRK_Marker
(_Marker_key, _Organism_key, _Marker_Type_key, _Marker_Status_key, symbol, name, chromosome, cmOffset, _CreatedBy_key, _ModifiedBy_key)
SELECT v_newKey, _Organism_key, _Marker_Type_key, 2, symbol||'_tmp', v_withdrawnName, chromosome, cmOffset, v_userKey, v_userKey
FROM MRK_Marker
WHERE _Marker_key = v_oldKey
;
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_simpleWithdrawal: Could not add marker (%)', v_newSymbol;
	RETURN;
END IF;
-- Update the Current marker of the new marker
UPDATE MRK_Current
SET _Current_key = v_oldKey
WHERE _Current_key = v_newKey;
-- handled by trigger
--INSERT INTO MRK_Current VALUES (v_oldKey, v_newKey, now(), now());
-- Update old marker record with new symbol and name values
UPDATE MRK_Marker
SET symbol = v_newSymbol, name = v_newName, _ModifiedBy_key = v_userKey, modification_date = now()
WHERE _Marker_key = v_oldKey;
-- Update old marker record with old symbol (remove '_tmp')
UPDATE MRK_Marker
SET symbol = v_savesymbol
WHERE _Marker_key = v_newKey;
-- Update history lines
UPDATE MRK_History
SET _History_key = v_newKey
WHERE _Marker_key = v_oldKey
AND _History_key = v_oldKey;
-- Add History line for withdrawal
PERFORM MRK_insertHistory (v_userKey, v_oldKey, v_newKey, v_refsKey, 106563605, v_eventReasonKey,
	(select oldName from mrk_tmp));
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_simpleWithdrawal: Could not add history (withdrawal)';
	RETURN;
END IF;
-- Add History line for assignment
PERFORM MRK_insertHistory (v_userKey, v_oldKey, v_oldKey, v_refsKey, 106563604, v_eventReasonKey, v_newName);
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_simpleWithdrawal: Could not add history (assignment)';
	RETURN;
END IF;
-- If marker type = 'gene' (1) and no wild type allele exists for new symbol, create it
--IF (SELECT _Marker_Type_key FROM MRK_Marker WHERE _Marker_key = v_newKey) = 1
	--AND NOT EXISTS (SELECT 1 FROM ALL_Allele WHERE _Marker_key = v_oldKey AND isWildType = 1)
--THEN
	--PERFORM ALL_createWildType (v_userKey, v_oldKey, v_newSymbol);
	--IF NOT FOUND
	--THEN
		--RAISE EXCEPTION E'\nMRK_simpleWithdrawal: Could not add wild type allele';
		--RETURN;
	--END IF;
--END IF;
-- Convert Alleles, if necessary
PERFORM ALL_convertAllele (v_userKey, v_oldKey, (select oldSymbol from mrk_tmp), v_newSymbol);
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_simpleWithdrawal: Could not call ALL_convertAllele';
	RETURN;
END IF;
-- Insert withdrawn symbol into Synonym table
-- Use assigning reference
IF v_addAsSynonym = 1
THEN
	PERFORM MGI_insertSynonym (v_userKey, v_oldKey, 2, 1004,
		(select oldSymbol from mrk_tmp),
		(select assigningRefKey from mrk_tmp), 1);
	IF NOT FOUND
	THEN
		RAISE EXCEPTION E'\nMRK_simpleWithdrawal: Could not add synonym';
		RETURN;
	END IF;
END IF;
-- Update needsReview flag for strains
PERFORM PRB_setStrainReview (v_oldKey);
IF NOT FOUND
THEN
	RAISE EXCEPTION E'\nMRK_simpleWithdrawal: Could not flag Strain record for needing review';
	RETURN;
END IF;
RETURN;
END;
$$;

/*
ERROR: invalid type name "prb_source.age%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.prb_ageminmax(v_age text, OUT v_agemin numeric, OUT v_agemax numeric) RETURNS record
    LANGUAGE plpgsql
    AS $$
DECLARE
saveAge prb_source.age%TYPE;
stem prb_source.age%TYPE;
timeUnit varchar(25);
timeRange varchar(25);
i integer;
idx integer;
idx2 integer;
minValue numeric;
maxValue numeric;
BEGIN
saveAge := v_age;
IF v_age = 'Not Specified'
	or v_age = 'Not Applicable'
	or v_age = 'Not Loaded'
	or v_age = 'Not Resolved'
THEN
	v_ageMin := -1.0;
	v_ageMax := -1.0;
ELSIF v_age = 'embryonic'
THEN
	v_ageMin := 0.0;
	v_ageMax := 21.0;
ELSIF v_age = 'postnatal'
THEN
	v_ageMin := 21.01;
	v_ageMax := 1846.0;
ELSIF v_age = 'postnatal newborn'
THEN
	v_ageMin := 21.01;
	v_ageMax := 25.0;
ELSIF v_age = 'postnatal adult'
THEN
	v_ageMin := 42.01;
	v_ageMax := 1846.0;
ELSIF v_age = 'postnatal day'
	or v_age = 'postnatal week'
	or v_age = 'postnatal month'
	or v_age = 'postnatal year'
	or v_age = 'embryonic day'
THEN
        RAISE NOTICE E'Invalid Age Value: "%"\n', saveAge;
	RETURN;
-- parse the age into 3 parts:
--     stem (embryonic, postnatal),
--     time unit (day, week, month year)
--     time range (x   x,y,z   x-y)
ELSE
    minValue := 5000.0;
    maxValue := -1.0;
    i := 0;
    WHILE v_age IS NOT NULL AND i < 3 LOOP
        idx := position(' ' in v_age);
        IF idx > 0 THEN
            IF i = 0 THEN
                stem := substring(v_age, 1, idx - 1);
            ELSIF i = 1 THEN
                timeUnit := substring(v_age, 1, idx - 1);
            ELSIF i = 1 THEN
                timeRange := substring(v_age, 1, char_length(v_age));
	    END IF;
            v_age := substring(v_age, idx + 1, char_length(v_age));
        ELSE
            timeRange := substring(v_age, 1, char_length(v_age));
            v_age := null;
        END IF;
        i := i + 1;
    END LOOP; -- WHILE v_age != null...
    -- once the stem, time unit and time range have been parsed,
    -- determine the format of the time range and process accordingly.
    -- format is:
    --     embryonic day x,y,z
    --     embryonic day x-y,z
    --     embryonic day x,y-z
    --
    -- we assume that x is the min and z is the max
    --
    -- NOTE:  there are very fiew of these cases (29 as of 07/23/2003)
    IF position(',' in timeRange) > 0 THEN
        WHILE timeRange IS NOT NULL LOOP
            idx := position(',' in timeRange);
            idx2 := position('-' in timeRange);
            IF idx2 > 0 THEN
                -- the x-y of an "x-y,z..."
                IF idx > idx2 THEN
                    IF minValue > substring(timeRange, 1, idx2 - 1)::NUMERIC THEN
                        minValue := substring(timeRange, 1, idx2 - 1)::NUMERIC;
		    END IF;
                    IF maxValue < substring(timeRange, idx2 + 1, idx - idx2 - 1)::NUMERIC THEN
                        maxValue := substring(timeRange, idx2 + 1, idx - idx2 - 1)::NUMERIC;
		    END IF;
                -- more timeRanges (more commas)
                ELSIF idx > 0 THEN
                    IF minValue > substring(timeRange, 1, idx - 1)::NUMERIC THEN
                        minValue := substring(timeRange, 1, idx - 1)::NUMERIC;
		    END IF;
                    IF maxValue < convert(numeric, substring(timeRange, 1, idx - 1)) THEN
                        maxValue := substring(timeRange, 1, idx - 1)::NUMERIC;
		    END IF;
                -- last timeRange
                ELSE
                    IF minValue > substring(timeRange, 1, idx2 - 1)::NUMERIC THEN
                        minValue := substring(timeRange, 1, idx2 - 1)::NUMERIC;
		    END IF;
                    IF maxValue < substring(timeRange, idx2 + 1, char_length(timeRange))::NUMERIC THEN
                        maxValue := substring(timeRange, idx2 + 1, char_length(timeRange))::NUMERIC;
		    END IF;
                END IF;
            ELSE
                -- more timeRanges
                IF idx > 0 THEN
                    IF minValue > substring(timeRange, 1, idx - 1)::NUMERIC THEN
                        minValue := substring(timeRange, 1, idx - 1)::NUMERIC;
                    END IF;
                    IF maxValue < substring(timeRange, 1, idx - 1)::NUMERIC THEN
                        maxValue := substring(timeRange, 1, idx - 1)::NUMERIC;
                    END IF;
                -- last timeRange
                ELSE
                    IF minValue > timeRange::NUMERIC THEN
                        minValue := timeRange::NUMERIC;
                    END IF;
                    IF maxValue < timeRange::NUMERIC THEN
                        maxValue := timeRange::NUMERIC;
		    END IF;
                END IF;
            END IF;
            IF position(',' in timeRange) = 0 THEN
                timeRange := null;
            ELSE
                timeRange := substring(timeRange, idx + 1, char_length(timeRange));
            END IF;
        END LOOP;
    ELSE
        -- format is:
        --     embryonic day x-y
        idx := position('-' in timeRange);
        IF idx > 0 THEN
            minValue := substring(timeRange, 1, idx - 1)::NUMERIC;
            maxValue := substring(timeRange, idx + 1, char_length(timeRange))::NUMERIC;
        -- format is:
        --     embryonic day x
        ELSE
            minValue := timeRange::NUMERIC;
            maxValue := timeRange::NUMERIC;
        END IF;
    END IF; -- end IF position(',' in timeRange) > 0 THEN
    IF minValue is null or maxValue is null THEN
        RETURN;
    END IF;
    -- multiply postnatal values according to time unit
    IF stem = 'postnatal' THEN
        IF timeUnit = 'day' THEN
            v_ageMin := minValue + 21.01;
            v_ageMax := maxValue + 21.01;
        ELSEIF timeUnit = 'week' THEN
            v_ageMin := minValue * 7 + 21.01;
            v_ageMax := maxValue * 7 + 21.01;
        ELSEIF timeUnit = 'month' THEN
            v_ageMin := minValue * 30 + 21.01;
            v_ageMax := maxValue * 30 + 21.01;
        ELSEIF timeUnit = 'year' THEN
            v_ageMin := minValue * 365 + 21.01;
            v_ageMax := maxValue * 365 + 21.01;
        END IF;
    ELSE
        v_ageMin := minValue;
        v_ageMax := maxValue;
    END IF;
END IF; -- final
IF stem = 'Not' AND v_ageMin >= 0
THEN
    RAISE NOTICE E'Invalid Age Value: "%"\n', saveAge;
    RETURN;
END IF;
IF stem = 'embryonic' AND timeUnit IS NULL AND timeRange IS NOT NULL
THEN
    RAISE NOTICE E'Invalid Age Value: "%"\n', saveAge;
    RETURN;
END IF;
IF v_ageMin IS NULL AND v_ageMax IS NULL THEN
    RAISE NOTICE E'Invalid Age Value: "%"\n', saveAge;
    RETURN;
END IF;
RETURN;
END;
$$;

/*
ERROR: invalid type name "acc_accession.accID%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.prb_mergestrain(v_oldstrainkey integer, v_newstrainkey integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_alleleKey int;
v_probe text;
v_jnum text;
v_strainAttributesType int;
v_oldNeedsReviewSum int;
v_newNeedsReviewSum int;
v_jaxRegistryNew acc_accession.accID%TYPE;
v_jaxRegistryOld acc_accession.accID%TYPE;
v_strainmergeKey int;
v_noteTypeKey int;
v_note1 text;
v_note2 text;
v_nextKey int;
v_synTypeKey int;
v_nextSeqKey int;
BEGIN
-- Update old Strain key to new Strain key
-- in all relevant tables which contain a Strain key.
-- When finished, remove the Strain record for the old Strain key.
IF v_oldStrainKey = v_newStrainKey
THEN
	RAISE EXCEPTION E'PRB_mergeStrain: Cannot merge a Strain into itself.';
	RETURN;
END IF;
-- Check for valid merge conditions
-- disallowed:
--	private -> public
--      public -> private
--      Standard -> Non Standard
IF (SELECT private FROM PRB_Strain WHERE _Strain_key = v_oldStrainKey) = 1
   AND
   (SELECT private FROM PRB_Strain WHERE _Strain_key = v_newStrainKey) = 0
THEN
	RAISE EXCEPTION E'PRB_mergeStrain: Cannot merge Private Strain into Public Strain.';
	RETURN;
END IF;
IF (SELECT private FROM PRB_Strain WHERE _Strain_key = v_oldStrainKey) = 0
   AND
   (SELECT private FROM PRB_Strain WHERE _Strain_key = v_newStrainKey) = 1
THEN
	RAISE EXCEPTION E'PRB_mergeStrain: Cannot merge Public Strain into Private Strain';
	RETURN;
END IF;
IF (SELECT standard FROM PRB_Strain WHERE _Strain_key = v_oldStrainKey) = 1
   AND
   (SELECT standard FROM PRB_Strain WHERE _Strain_key = v_newStrainKey) = 0
THEN
	RAISE EXCEPTION E'PRB_mergeStrain: Cannot merge Standard Strain into Non-Standard Strain';
	RETURN;
END IF;
-- Check for potential duplicate Probe RFLV Entries
FOR v_alleleKey IN
SELECT DISTINCT _Allele_key
FROM PRB_Allele_Strain
WHERE _Strain_key in (v_oldStrainKey, v_newStrainkey)
GROUP by _Allele_key having count(*) > 1
LOOP
	SELECT p.name as v_probe, b.accID as v_jnum
	FROM PRB_Allele a, PRB_RFLV v, PRB_Reference  r, PRB_Probe p, BIB_Acc_View b
	WHERE a._Allele_key = v_alleleKey and
	      a._RFLV_key = v._RFLV_key and
	      v._Reference_key = r._Reference_key and
	      r._Probe_key = p._Probe_key and
	      r._Refs_key = b._Object_key and
	      b.prefixPart = 'J:' and
	      b._LogicalDB_key = 1
        ;
	RAISE EXCEPTION E'PRB_mergeStrain: This merge would create a duplicate entry for Probe %, %.', v_probe, v_jnum;
	RETURN;
END LOOP;
-- all Strains must have same symbols
IF EXISTS (SELECT m1.* FROM PRB_Strain_Marker m1
           WHERE m1._Strain_key = v_newStrainKey
	   AND NOT EXISTS
	   (SELECT m2.* FROM PRB_Strain_Marker m2
	    WHERE m2._Strain_key = v_oldStrainKey AND
	    m2._Marker_key = m1._Marker_key))
THEN
	RAISE EXCEPTION E'PRB_mergeStrain: Incorrect and Correct Strains must have the same Marker Symbols.';
	RETURN;
END IF;
IF EXISTS (SELECT m1.* FROM PRB_Strain_Marker m1
           WHERE m1._Strain_key = v_oldStrainKey
	   AND NOT EXISTS
	   (SELECT m2.* FROM PRB_Strain_Marker m2
	    WHERE m2._Strain_key = v_newStrainKey AND
	    m2._Marker_key = m1._Marker_key))
THEN
	RAISE EXCEPTION E'PRB_mergeStrain: Incorrect and Correct Strains must have the same Marker Symbols.';
	RETURN;
END IF;
-- both Strains must have the same Strain Attributes
--v_strainAttributesType := _AnnotType_key from VOC_AnnotType WHERE name = 'Strain/Attributes';
--v_strainmergeKey := _User_key from MGI_User WHERE login = 'strainmerge';
v_strainAttributesType := 1009;
v_strainmergeKey := 1400;
IF EXISTS (SELECT m1.* FROM VOC_Annot m1
           WHERE m1._Object_key = v_newStrainKey
	   AND m1._AnnotType_key = v_strainAttributesType
	   AND NOT EXISTS
	   (SELECT m2.* FROM VOC_Annot m2
	    WHERE m2._Object_key = v_oldStrainKey
	    AND m2._AnnotType_key = v_strainAttributesType
	    AND m2._Term_key = m1._Term_key))
THEN
	RAISE EXCEPTION E'PRB_mergeStrain: Incorrect and Correct Strains must have the same Strain Attributes.';
	RETURN;
END IF;
IF EXISTS (SELECT m1.* FROM VOC_Annot m1
           WHERE m1._Object_key = v_oldStrainKey
	   AND m1._AnnotType_key = v_strainAttributesType
	   AND NOT EXISTS
	   (SELECT m2.* FROM VOC_Annot m2
	    WHERE m2._Object_key = v_newStrainKey
	    AND m2._AnnotType_key = v_strainAttributesType
	    AND m2._Term_key = m1._Term_key))
THEN
	RAISE EXCEPTION E'PRB_mergeStrain: Incorrect and Correct Strains must have the same Strain Attributes.';
	RETURN;
END IF;
-- both Strains must have the same Species value
IF (SELECT _Species_key FROM PRB_Strain WHERE _Strain_key = v_newStrainKey) !=
   (SELECT _Species_key FROM PRB_Strain WHERE _Strain_key = v_oldStrainKey)
THEN
	RAISE EXCEPTION E'PRB_mergeStrain: Incorrect and Correct Strains must have the same Species.';
	RETURN;
END IF;
-- both Strains must have the same Needs Review values
v_oldNeedsReviewSum := sum(_Term_key) from PRB_Strain_NeedsReview_View WHERE _Object_key = v_oldStrainKey;
v_newNeedsReviewSum := sum(_Term_key) from PRB_Strain_NeedsReview_View WHERE _Object_key = v_newStrainKey;
IF (v_oldNeedsReviewSum != v_newNeedsReviewSum)
THEN
	RAISE EXCEPTION E'PRB_mergeStrain: Incorrect and Correct Strains must have the same Needs Review values.';
	RETURN;
END IF;
-- JAX Registry - must be equal OR use the one that exists
v_jaxRegistryNew := NULL;
v_jaxRegistryOld := NULL;
IF EXISTS (SELECT accID FROM ACC_Accession
	   WHERE _Object_key = v_newStrainKey and _LogicalDB_Key = 22 and _MGIType_key = 10)
THEN
	v_jaxRegistryNew := accID FROM ACC_Accession
		WHERE _Object_key = v_newStrainKey and _LogicalDB_Key = 22 and _MGIType_key = 10;
END IF;
IF EXISTS (SELECT _Accession_key FROM ACC_Accession
           WHERE _Object_key = v_oldStrainKey and _LogicalDB_Key = 22 and _MGIType_key = 10)
THEN
	v_jaxRegistryOld := accID FROM ACC_Accession
		WHERE _Object_key = v_oldStrainKey and _LogicalDB_Key = 22 and _MGIType_key = 10;
END IF;
IF (v_jaxRegistryNew != NULL AND v_jaxRegistryOld != NULL AND v_jaxRegistryNew != v_jaxRegistryOld)
THEN
	RAISE EXCEPTION E'PRB_mergeStrain: Incorrect and Correct Strains must have the same JAX Registry Number.';
	RETURN;
ELSIF (v_jaxRegistryOld != NULL)
THEN
    v_jaxRegistryNew := v_jaxRegistryOld;
END IF;
-- Set the preferred bit to 0 for all MGI Acc# brought over from old strain.
UPDATE ACC_Accession
SET _Object_key = v_newStrainKey, preferred = 0
WHERE _LogicalDB_key = 1 and _MGIType_key = 10 and _Object_key = v_oldStrainKey
;
-- remove any Accession records belonging to old strain
-- which already exist for new strain
-- that is, remove duplicates before updating keys
DELETE FROM ACC_Accession old
USING ACC_Accession new
WHERE old._MGIType_key = 10
AND old._Object_key = v_oldStrainKey
AND old.accID = new.accID
AND old._LogicalDB_key = new._LogicalDB_key
AND new._Object_key = v_newStrainKey
AND new._MGIType_key = 10
;
UPDATE ACC_Accession
SET _Object_key = v_newStrainKey
WHERE _MGIType_key = 10 and _Object_key = v_oldStrainKey
;
UPDATE ALL_Allele
SET _Strain_key = v_newStrainKey, _ModifiedBy_key = v_strainmergeKey, modification_date = now()
WHERE _Strain_key = v_oldStrainKey
;
UPDATE ALL_CellLine
SET _Strain_key = v_newStrainKey
WHERE _Strain_key = v_oldStrainKey
;
UPDATE PRB_Source
SET _Strain_key = v_newStrainKey, _ModifiedBy_key = v_strainmergeKey, modification_date = now()
WHERE _Strain_key = v_oldStrainKey
;
UPDATE PRB_Allele_Strain
SET _Strain_key = v_newStrainKey, _ModifiedBy_key = v_strainmergeKey, modification_date = now()
WHERE _Strain_key = v_oldStrainKey
;
UPDATE MLD_FISH
SET _Strain_key = v_newStrainKey
WHERE _Strain_key = v_oldStrainKey
;
UPDATE MLD_InSitu
SET _Strain_key = v_newStrainKey
WHERE _Strain_key = v_oldStrainKey
;
UPDATE CRS_Cross
SET _femaleStrain_key = v_newStrainKey
WHERE _femaleStrain_key = v_oldStrainKey
;
UPDATE CRS_Cross
SET _maleStrain_key = v_newStrainKey
WHERE _maleStrain_key = v_oldStrainKey
;
UPDATE CRS_Cross
SET _StrainHO_key = v_newStrainKey
WHERE _StrainHO_key = v_oldStrainKey
;
UPDATE CRS_Cross
SET _StrainHT_key = v_newStrainKey
WHERE _StrainHT_key = v_oldStrainKey
;
UPDATE GXD_Genotype
SET _Strain_key = v_newStrainKey, _ModifiedBy_key = v_strainmergeKey, modification_date = now()
WHERE _Strain_key = v_oldStrainKey
;
UPDATE RI_RISet
SET _Strain_key_1 = v_newStrainKey
WHERE _Strain_key_1 = v_oldStrainKey
;
UPDATE RI_RISet
SET _Strain_key_2 = v_newStrainKey
WHERE _Strain_key_2 = v_oldStrainKey
;
-- NOTES
FOR v_noteTypeKey IN
SELECT _NoteType_key
FROM MGI_NoteType_Strain_View
LOOP
    -- if both old and new strains have notes, concatenate old notes onto new notes
    IF EXISTS (select 1 from MGI_Note
		WHERE _MGIType_key = 10 and _NoteType_key = v_noteTypeKey and _Object_key = v_newStrainKey)
       AND
       EXISTS (select 1 from MGI_Note
		WHERE _MGIType_key = 10 and _NoteType_key = v_noteTypeKey and _Object_key = v_oldStrainKey)
    THEN
    	v_note1 := n.note from MGI_Note n WHERE n._MGIType_key = 10 and n._NoteType_key = v_noteTypeKey and n._Object_key = v_newStrainKey;
	v_note2 := n.note from MGI_Note n WHERE n._MGIType_key = 10 and n._NoteType_key = v_noteTypeKey and n._Object_key = v_oldStrainKey;
        IF v_note1 != v_note2
        THEN
                v_note1 = v_note1 || E'\n' || v_note2;
        END IF;
	UPDATE MGI_Note
	SET note = v_note1
	WHERE _MGIType_key = 10
	      AND _NoteType_key = v_noteTypeKey
	      AND _Object_key = v_newStrainKey
	;
	DELETE FROM MGI_Note WHERE _MGIType_key = 10 and _NoteType_key = v_noteTypeKey and _Object_key = v_oldStrainKey;
    -- else if only old strain has notes, move old notes to new notes
    ELSIF NOT EXISTS (SELECT 1 FROM MGI_Note
		WHERE _MGIType_key = 10 and _NoteType_key = v_noteTypeKey and _Object_key = v_newStrainKey)
       AND
       EXISTS (SELECT 1 FROM MGI_Note
		WHERE _MGIType_key = 10 and _NoteType_key = v_noteTypeKey and _Object_key = v_oldStrainKey)
    THEN
        UPDATE MGI_Note
        SET _Object_key = v_newStrainKey
        WHERE _MGIType_key = 10 and _NoteType_key = v_noteTypeKey and _Object_key = v_oldStrainKey
	;
    END IF;
    -- else if only new strain has notes, do nothing
END LOOP;
-- END NOTES
-- STRAIN/MARKER/ALLELES
-- remove duplicates
DELETE FROM PRB_Strain_Marker p1
USING PRB_Strain_Marker p2
WHERE p1._Strain_key = v_oldStrainKey
AND p1._Marker_key = p2._Marker_key
AND p1._Allele_key = p2._Allele_key
AND p2._Strain_key = v_newStrainKey
;
UPDATE PRB_Strain_Marker
SET _Strain_key = v_newStrainKey
WHERE _Strain_key = v_oldStrainKey
;
-- TRANSLATIONS
-- remove duplicates
DELETE FROM MGI_Translation t1
USING MGI_TranslationType tt, MGI_Translation t2
WHERE tt._MGIType_key = 10
and tt._TranslationType_key = t1._TranslationType_key
and t1._Object_key = v_oldStrainKey
and tt._TranslationType_key = t2._TranslationType_key
and t2._Object_key = v_newStrainKey
and t1.badName = t2.badName
;
UPDATE MGI_Translation
SET _Object_key = v_newStrainKey
FROM MGI_TranslationType tt
WHERE tt._MGIType_key = 10
AND tt._TranslationType_key = MGI_Translation._TranslationType_key
AND MGI_Translation._Object_key = v_oldStrainKey
;
-- SETS
-- remove duplicates
DELETE FROM MGI_SetMember s1
USING MGI_Set s, MGI_SetMember s2
WHERE s._MGIType_key = 10
AND s._Set_key = s1._Set_key
AND s1._Object_key = v_oldStrainKey
AND s._Set_key = s2._Set_key
AND s2._Object_key = v_newStrainKey
;
UPDATE MGI_SetMember
SET _Object_key = v_newStrainKey
FROM MGI_Set s
WHERE s._MGIType_key = 10
and s._Set_key = MGI_SetMember._Set_key
and MGI_SetMember._Object_key = v_oldStrainKey
;
-- SYNONYMS
UPDATE MGI_Synonym
SET _Object_key = v_newStrainKey
WHERE _Object_key = v_oldStrainKey
AND _MGIType_key = 10
;
-- if the strain names are not equal
--   a.  make old strain name a synonym of the new strain
--   b.  make old strain name a translation of the new strain
IF (SELECT strain FROM PRB_Strain WHERE _Strain_key = v_oldStrainKey) !=
   (SELECT strain FROM PRB_Strain WHERE _Strain_key = v_newStrainKey)
THEN
	v_nextKey := nextval('mgi_synonym_seq');
	--v_synTypeKey := _SynonymType_key from MGI_SynonymType_Strain_View  WHERE synonymType = 'nomenclature history';
	v_synTypeKey := 1001;
	IF v_nextKey IS NULL
	THEN
		v_nextKey := 1000;
	END IF;
	INSERT INTO MGI_Synonym (_Synonym_key, _MGIType_key, _Object_key, _SynonymType_key, _Refs_key, synonym)
	SELECT v_nextKey, 10, v_newStrainKey, v_synTypeKey, null, strain
	FROM PRB_Strain WHERE _Strain_key = v_oldStrainKey
	;
	v_nextKey := max(_Translation_key) + 1 from MGI_Translation;
	v_nextSeqKey := max(sequenceNum) + 1 from MGI_Translation WHERE _TranslationType_key = 1007;
	INSERT INTO MGI_Translation (_Translation_key, _TranslationType_key, _Object_key, badName, sequenceNum,
		_CreatedBy_key, _ModifiedBy_key, creation_date, modification_date)
	SELECT v_nextKey, 1007, v_newStrainKey, strain, v_nextSeqKey, v_strainmergeKey, v_strainmergeKey,
		now(), now()
	FROM PRB_Strain WHERE _Strain_key = v_oldStrainKey
	;
END IF;
DELETE FROM PRB_Strain WHERE _Strain_key = v_oldStrainKey;
END;
$$;

/*
ERROR: invalid type name "acc_accession.accID%TYPE" (SQLSTATE 42601)
File :/home/ubuntu/yb-voyager/migtests/tests/pg/mgi/export-dir/schema/functions/function.sql
*/
CREATE FUNCTION mgd.seq_split(v_fromseqid text, v_toseqids text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
v_fromSeqKey int;
v_splitStatusKey int;
v_toSeqKey int;
v_toAccID acc_accession.accID%TYPE;
v_idx text;
v_accID acc_accession.accID%TYPE;
v_logicalDB int;
BEGIN
-- Split v_fromSeqID to v_toSeqIDs
-- where v_toSeqIDs is a comma-separated list of Seq IDs to split the v_fromSeqID into
-- 1) Copy non-duplicate "from" Accession IDs to each "to" Sequence object and make them Secondary IDs
-- 2) Status the "from" Sequence object as "Split"
v_fromSeqKey := _Object_key from SEQ_Sequence_Acc_View where accID = v_fromSeqID and preferred = 1;
v_splitStatusKey := _Term_key from VOC_Term where _Vocab_key = 20 and term = 'SPLIT';
IF v_fromSeqKey IS NULL
THEN
	RAISE EXCEPTION 'SEQ_split: Could not resolve %.', v_fromSeqID;
	RETURN;
END IF;
-- delete cache entries from old sequence
DELETE FROM SEQ_Marker_Cache where _Sequence_key = v_fromSeqKey;
DELETE FROM SEQ_Probe_Cache where _Sequence_key = v_fromSeqKey;
-- For each new Sequence:
--      1. copy non-duplicate "from" Accession IDs to each "to" Sequence object and make them Secondary IDs
--      2. re-load SEQ_Marker_Cache
--      3. re-load SEQ_Probe_Cache
WHILE (v_toSeqIDs != NULL) LOOP
	v_idx := position(',' in v_toSeqIDs);
	IF v_idx > 0
	THEN
		v_toAccID := substring(v_toSeqIDs, 1, v_idx - 1);
		v_toSeqIDs := substring(v_toSeqIDs, v_idx + 1, char_length(v_toSeqIDs));
	ELSE
		-- at end of list of v_toSeqIDs
		v_toAccID := v_toSeqIDs;
		v_toSeqIDs := NULL;
	END IF;
	IF v_toAccID != NULL
	THEN
		v_toSeqKey := _Object_key from SEQ_Sequence_Acc_View where accID = v_toAccID and preferred = 1;
		IF v_toSeqKey is null
		THEN
			RAISE EXCEPTION E'SEQ_split: Could not resolve %.', v_toAccID;
			RETURN;
		END IF;
                -- delete cache entries from new sequence
                DELETE FROM SEQ_Marker_Cache where _Sequence_key = v_toSeqKey;
                DELETE FROM SEQ_Probe_Cache where _Sequence_key = v_toSeqKey;
		-- copy all Accession IDs of v_fromSeqKey to v_toSeqKey - make them all secondary
		FOR v_accID, v_logicalDB IN
		SELECT a1.accID, a1._LogicalDB_key
		FROM ACC_Accession a1
		WHERE a1._MGIType_key = 19
		AND a1._Object_key = v_fromSeqKey
		AND NOT EXISTS (SELECT 1 FROM ACC_Accession a2
			WHERE a2._MGIType_key = 19
			AND a2._Object_key = v_toSeqKey
			AND a2.accID = a1.accID)
		LOOP
			PERFORM ACC_insert (1001, v_toSeqKey, v_accID, v_logicalDB, 'Sequence', -1, 0, 0);
		END LOOP;
	END IF;
END LOOP;
-- Now make the final necessary modifications to the old Sequence object */
UPDATE SEQ_Sequence
SET _SequenceStatus_key = v_splitStatusKey, _ModifiedBy_key = 1001, modification_date = now()
WHERE _Sequence_key = v_fromSeqKey
;
END;
$$;

