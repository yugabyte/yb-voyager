\i sql/00_create_users_roles.ddl.sql  
\i sql/03_create_extension.ddl.sql 
\i sql/04_create_composite_type.ddl.sql        
\i sql/05_create_enum_type.ddl.sql 
\i sql/06_create_range_type.sql  
\i sql/07_create_base_type.ddl.sql  
\i sql/08_create_domain.ddl.sql  
\i sql/09_create_foreign.ddl.sql   
\i sql/10_create_function.ddl.sql 
\i sql/11_create_ordinary_table.ddl.sql  
\i sql/12_create_cast.ddl.sql     
\i sql/13_create_conversion.ddl.sql  
\i sql/14_create_access_method.ddl.sql          
\i sql/15_create_aggregate.ddl.sql
\i sql/16_create_collation.ddl.sql   
\i sql/17_create_trigger.ddl.sql
\i sql/18_create_index.ddl.sql
\i sql/19_create_policy.ddl.sql
\i sql/99_create_event_trigger.ddl.sql

       
 
      

      
   
    


   

